package com.nat.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class BookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Book2> bookList = new ArrayList();

		bookList.add(new Book2(1, "Book 1", "Author A", 1200, 5000));
		bookList.add(new Book2(2, "Book 2", "Author M", 2100, 2000));
		bookList.add(new Book2(3, "Book 3", "Author A", 3000, 6000));
		bookList.add(new Book2(4, "Book 4", "Author D", 800, 2800));
		bookList.add(new Book2(5, "Book 5", "Author M", 7200, 1100));
		bookList.add(new Book2(6, "Book 6", "Author A", 8200, 4300));
		bookList.add(new Book2(7, "Book 7", "Author A", 7900, 5600));
		
		//
		//bookList.stream()
		//.filter(book->book.getPrice()>5000)
		//.map(book->new BookDiscount(book, book.getPrice()*.10))
		//.forEach(bookWithDiscount->System.out.println(bookWithDiscount));
		
		//should return book discount object
		bookList.stream()
		.map(new Function<Book2, BookDiscount>() {

			@Override
			public BookDiscount apply(Book2 book) {
				BookDiscount bookD = null;
				if(book.getPrice() <= 5000) {
					bookD = new BookDiscount(book, book.getPrice()*0.05);
				}else {
					bookD = new BookDiscount(book, book.getPrice()*0.10);
				}
				return bookD;
			}
			
		}).forEach(book -> System.out.println(book));
		
		//a break
		System.out.println("======================");
		
		
		//do the lambda way 
		bookList.stream()
		.map(book ->{
				BookDiscount bookD = null;
				if(book.getPrice() <= 5000) {
					bookD = new BookDiscount(book, book.getPrice()*0.05);
				}else {
					bookD = new BookDiscount(book, book.getPrice()*0.10);
				}
				return bookD;
			}
			
		).forEach(book -> System.out.println(book));
		
		
		
	}

}
