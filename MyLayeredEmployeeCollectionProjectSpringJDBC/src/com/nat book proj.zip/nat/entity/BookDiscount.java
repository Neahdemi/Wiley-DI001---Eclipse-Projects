package com.nat.entity;

public class BookDiscount {
	private Book2 book;
	private double discount;
	
	public BookDiscount() {
		
	}

	public BookDiscount(Book2 book, double discount) {
		super();
		this.book = book;
		this.discount = discount;
	}

	public Book2 getBook() {
		return book;
	}

	public void setBook(Book2 book) {
		this.book = book;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "BookDiscount [book=" + book + ", discount=" + discount + "]";
	}
}
