package com.nat.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BookServiceTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testAddBook() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchBook() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllBooks() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchBookById() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdateBook() {
		fail("Not yet implemented");
	}

}
