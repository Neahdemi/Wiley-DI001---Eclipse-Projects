package com.nat.presentation;

public interface BookPresentation {

	void showMenu();
	void performMenu(int choice);
	
	
}
